Program Blocker 2.0 Rev 1 (03/03/2025)
---------------
Whats New:
* Added Block Firewall function
* Added a quick action option in selecting programs
* Change the block and unblock control menus, with actions for the selected program or all programs in the list.
* Delete the tutorial in the program and change it with keyboard shortcut information.
* Discontinued support for Windows Vista. (maybe on a build version of windows vista, it will still run)

Program Blocker 1.0 Rev 3
---------------
Whats New:
* Fix some bugs