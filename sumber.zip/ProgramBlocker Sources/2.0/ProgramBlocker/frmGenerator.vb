﻿Public Class frmGenerator

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        ' Generate 5 key sekaligus
        Dim sb As New System.Text.StringBuilder()
        For i As Integer = 1 To 5
            sb.AppendLine(LicenseManager.GenerateKey())
        Next
        TextBox1.Text = sb.ToString().Trim()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        If TextBox1.Text.Trim().Length > 0 Then
            Clipboard.SetText(TextBox1.Text)
            MsgBox("Keys copied to clipboard!", MsgBoxStyle.Information, "Copied")
        End If

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim key As String = TextBox2.Text.Trim()
        If LicenseManager.IsValidKey(key) Then
            MsgBox("VALID key!")
        Else
            MsgBox("INVALID key.")
        End If

    End Sub

    Private Sub frmGenerator_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class