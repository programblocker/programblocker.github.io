﻿Imports System.IO
Imports Microsoft.Win32

Public Class Form1
    ' ================================================================
    '  CONSTANTS
    ' ================================================================
    Private Const DIRECTION_INBOUND As Integer = 1
    Private Const DIRECTION_OUTBOUND As Integer = 2
    Private Const ACTION_BLOCK As Integer = 0
    Private Const IFEO_KEY As String = "SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options"
    Private Const DEBUGGER_BLOCK As String = "svchost.exe"

    Private ReadOnly SaveFile As String = Path.Combine(Application.StartupPath, "blocklist.dat")

    Private Const COL_NAME As Integer = 0
    Private Const COL_PATH As Integer = 1
    Private Const COL_INTERNET As Integer = 2
    Private Const COL_RUN As Integer = 3
    Private Const COL_STATUS As Integer = 4

    Private _isLicensed As Boolean = False

    ' ================================================================
    '  FORM LOAD & CLOSE
    ' ================================================================
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Icon = My.Resources.favicon
        SetupDataGridView()
        LoadSavedList()
        RefreshAllStatus()
        lblInfo.Text = "Status updated: " & Now.ToString("HH:mm:ss")

        _isLicensed = LicenseManager.LoadAndValidateLicense()
        UpdateLicenseUI()
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        SaveList()
    End Sub

    ' ================================================================
    '  UPDATE UI SESUAI STATUS LISENSI / TRIAL
    ' ================================================================
    Private Sub UpdateLicenseUI()
        If _isLicensed Then
            lblLicenseStatus.Text = "Licensed"
            lblLicenseStatus.ForeColor = Color.Black
            ActivateToolStripMenuItem.Text = "License: Active"
        Else
            Dim remaining As Integer = LicenseManager.GetTrialRemaining()
            If remaining > 0 Then
                lblLicenseStatus.Text = "Trial  -  " & remaining & " free use(s) remaining"
                lblLicenseStatus.ForeColor = Color.DarkOrange
            Else
                lblLicenseStatus.Text = "Trial expired  -  Activate to continue"
                lblLicenseStatus.ForeColor = Color.Red
            End If
            ActivateToolStripMenuItem.Text = "Activate License..."
        End If

        If dgvBlockList.SelectedRows.Count > 0 Then
            UpdateActionButtons(dgvBlockList.SelectedRows(0))
        Else
            ResetActionButtons()
        End If
    End Sub

    ' ================================================================
    '  CEK HAK AKSES BLOCK EXECUTION
    '  Return True  = boleh lanjut
    '  Return False = tidak boleh, sudah diinfo ke user
    ' ================================================================
    Private Function CanUseExecutionBlock() As Boolean
        ' Sudah licensed -> langsung boleh
        If _isLicensed Then Return True

        Dim remaining As Integer = LicenseManager.GetTrialRemaining()

        ' Masih ada sisa trial
        If remaining > 0 Then
            ' Tampilkan peringatan sisa trial (tapi tetap boleh lanjut)
            If remaining = 1 Then
                ' Peringatan terakhir kali
                Dim warn As MsgBoxResult = MsgBox( _
                    "This is your LAST free use of Block Execution." & vbCrLf & vbCrLf & _
                    "After this, you will need a valid license to continue." & vbCrLf & _
                    "Activate now, or use the last remaining trial?", _
                    MsgBoxStyle.Exclamation Or MsgBoxStyle.YesNo, "Last Free Use")
                If warn = MsgBoxResult.Yes Then
                    ShowActivationForm()
                    Return _isLicensed  ' lanjut hanya kalau berhasil aktivasi
                End If
            ElseIf remaining <= 3 Then
                ' Peringatan hampir habis (sisa 2-3)
                MsgBox( _
                    "Block Execution trial: " & remaining & " free use(s) remaining." & vbCrLf & _
                    "Consider activating your license before it runs out.", _
                    MsgBoxStyle.Information, "Trial Reminder")
            End If

            ' Catat pemakaian, lanjutkan
            LicenseManager.IncrementTrialUsage()
            UpdateLicenseUI()
            Return True
        End If

        ' Trial habis -> paksa aktivasi
        Dim result As MsgBoxResult = MsgBox( _
            "Your 10 free uses of Block Execution have been used up." & vbCrLf & vbCrLf & _
            "Please activate your license to continue using this feature." & vbCrLf & _
            "Click YES to enter your serial key now.", _
            MsgBoxStyle.Question Or MsgBoxStyle.YesNo, "Trial Expired")

        If result = MsgBoxResult.Yes Then
            ShowActivationForm()
        End If

        Return _isLicensed
    End Function

    ' ================================================================
    '  FORM AKTIVASI
    ' ================================================================
    Private Sub ShowActivationForm()
        Using frm As New frmActivation()
            frm.ShowDialog(Me)
            If frm.ActivationSuccess Then
                _isLicensed = True
                UpdateLicenseUI()
                MsgBox("Block Execution feature is now fully unlocked!", MsgBoxStyle.Information, "Activated")
            End If
        End Using
    End Sub

    Private Sub ActivateToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ActivateToolStripMenuItem.Click
        If _isLicensed Then
            MsgBox("Your license is active. Block Execution is fully unlocked.", MsgBoxStyle.Information, "License Status")
        Else
            Dim remaining As Integer = LicenseManager.GetTrialRemaining()
            Dim info As String = "Trial uses remaining: " & remaining & " / " & LicenseManager.GetMaxTrial() & vbCrLf & vbCrLf & _
                                 "Activate now to get unlimited access."
            If MsgBox(info, MsgBoxStyle.Question Or MsgBoxStyle.YesNo, "Activate License") = MsgBoxResult.Yes Then
                ShowActivationForm()
            End If
        End If
    End Sub

    ' ================================================================
    '  SETUP DATAGRIDVIEW
    ' ================================================================
    Private Sub SetupDataGridView()
        dgvBlockList.Columns.Clear()
        dgvBlockList.AllowUserToAddRows = False
        dgvBlockList.AllowUserToDeleteRows = False
        dgvBlockList.ReadOnly = True
        dgvBlockList.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        dgvBlockList.MultiSelect = False
        dgvBlockList.RowHeadersVisible = False
        dgvBlockList.BackgroundColor = System.Drawing.Color.White
        dgvBlockList.BorderStyle = BorderStyle.None
        dgvBlockList.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal
        dgvBlockList.GridColor = System.Drawing.Color.FromArgb(220, 220, 230)
        dgvBlockList.Font = New System.Drawing.Font("Segoe UI", 8.5!)

        dgvBlockList.ColumnHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(30, 30, 50)
        dgvBlockList.ColumnHeadersDefaultCellStyle.ForeColor = System.Drawing.Color.White
        dgvBlockList.ColumnHeadersDefaultCellStyle.Font = New System.Drawing.Font("Segoe UI", 8.5!, System.Drawing.FontStyle.Bold)
        dgvBlockList.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
        dgvBlockList.ColumnHeadersHeight = 32
        dgvBlockList.EnableHeadersVisualStyles = False

        dgvBlockList.RowsDefaultCellStyle.BackColor = System.Drawing.Color.White
        dgvBlockList.AlternatingRowsDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(248, 248, 252)
        dgvBlockList.RowsDefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(40, 40, 60)
        dgvBlockList.RowsDefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(210, 225, 255)
        dgvBlockList.RowsDefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(20, 20, 50)
        dgvBlockList.DefaultCellStyle.Padding = New Padding(4, 0, 4, 0)
        dgvBlockList.RowTemplate.Height = 28

        Dim colName As New DataGridViewTextBoxColumn()
        colName.Name = "colName" : colName.HeaderText = "Program" : colName.Width = 160 : colName.ReadOnly = True
        dgvBlockList.Columns.Add(colName)

        Dim colPath As New DataGridViewTextBoxColumn()
        colPath.Name = "colPath" : colPath.HeaderText = "Path" : colPath.Width = 220 : colPath.ReadOnly = True
        dgvBlockList.Columns.Add(colPath)

        Dim colInternet As New DataGridViewTextBoxColumn()
        colInternet.Name = "colInternet" : colInternet.HeaderText = "Internet" : colInternet.Width = 100 : colInternet.ReadOnly = True
        colInternet.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        dgvBlockList.Columns.Add(colInternet)

        Dim colRun As New DataGridViewTextBoxColumn()
        colRun.Name = "colRun" : colRun.HeaderText = "Execution" : colRun.Width = 100 : colRun.ReadOnly = True
        colRun.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        dgvBlockList.Columns.Add(colRun)

        Dim colStatus As New DataGridViewTextBoxColumn()
        colStatus.Name = "colStatus" : colStatus.HeaderText = "Status" : colStatus.Width = 130 : colStatus.ReadOnly = True
        colStatus.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        colStatus.DefaultCellStyle.Font = New System.Drawing.Font("Segoe UI", 8.5!, System.Drawing.FontStyle.Bold)
        dgvBlockList.Columns.Add(colStatus)
    End Sub

    ' ================================================================
    '  TAMBAH PROGRAM
    ' ================================================================
    Private Sub ToolStripButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton1.Click
        Me.ActiveControl = Nothing
        Dim ofd As New OpenFileDialog()
        ofd.Filter = "Executable Files (*.exe)|*.exe|All Files (*.*)|*.*"
        ofd.Title = "Choose .EXE"
        ofd.Multiselect = True
        If ofd.ShowDialog() = DialogResult.OK Then
            For Each filePath As String In ofd.FileNames
                Dim alreadyExist As Boolean = False
                For Each row As DataGridViewRow In dgvBlockList.Rows
                    If row.Cells(COL_PATH).Value IsNot Nothing Then
                        If row.Cells(COL_PATH).Value.ToString().ToLower() = filePath.ToLower() Then
                            alreadyExist = True : Exit For
                        End If
                    End If
                Next
                If Not alreadyExist Then AddRowToGrid(filePath)
            Next
            SaveList()
            RefreshAllStatus()
        End If
    End Sub

    Private Sub AddRowToGrid(ByVal filePath As String)
        Dim rowIdx As Integer = dgvBlockList.Rows.Add()
        Dim row As DataGridViewRow = dgvBlockList.Rows(rowIdx)
        row.Cells(COL_NAME).Value = Path.GetFileName(filePath)
        row.Cells(COL_PATH).Value = filePath
        UpdateRowCells(row, CheckFirewallRuleExists(filePath), CheckRunBlockExists(filePath))
    End Sub

    ' ================================================================
    '  UPDATE STATUS SEL
    ' ================================================================
    Private Sub UpdateRowCells(ByVal row As DataGridViewRow, ByVal internetBlocked As Boolean, ByVal runBlocked As Boolean)
        If internetBlocked Then
            row.Cells(COL_INTERNET).Value = "BLOCKED"
            row.Cells(COL_INTERNET).Style.ForeColor = System.Drawing.Color.White
            row.Cells(COL_INTERNET).Style.BackColor = System.Drawing.Color.FromArgb(190, 50, 50)
        Else
            row.Cells(COL_INTERNET).Value = "None"
            row.Cells(COL_INTERNET).Style.ForeColor = System.Drawing.Color.FromArgb(30, 120, 30)
            row.Cells(COL_INTERNET).Style.BackColor = System.Drawing.Color.FromArgb(220, 245, 220)
        End If

        If runBlocked Then
            row.Cells(COL_RUN).Value = "BLOCKED"
            row.Cells(COL_RUN).Style.ForeColor = System.Drawing.Color.White
            row.Cells(COL_RUN).Style.BackColor = System.Drawing.Color.FromArgb(190, 50, 50)
        Else
            row.Cells(COL_RUN).Value = "None"
            row.Cells(COL_RUN).Style.ForeColor = System.Drawing.Color.FromArgb(30, 120, 30)
            row.Cells(COL_RUN).Style.BackColor = System.Drawing.Color.FromArgb(220, 245, 220)
        End If

        If internetBlocked AndAlso runBlocked Then
            row.Cells(COL_STATUS).Value = "FULL BLOCKED"
            row.Cells(COL_STATUS).Style.ForeColor = System.Drawing.Color.White
            row.Cells(COL_STATUS).Style.BackColor = System.Drawing.Color.FromArgb(160, 30, 30)
        ElseIf internetBlocked OrElse runBlocked Then
            row.Cells(COL_STATUS).Value = "PARTIAL BLOCKED"
            row.Cells(COL_STATUS).Style.ForeColor = System.Drawing.Color.White
            row.Cells(COL_STATUS).Style.BackColor = System.Drawing.Color.FromArgb(200, 130, 0)
        Else
            row.Cells(COL_STATUS).Value = "None"
            row.Cells(COL_STATUS).Style.ForeColor = System.Drawing.Color.FromArgb(30, 100, 30)
            row.Cells(COL_STATUS).Style.BackColor = System.Drawing.Color.FromArgb(210, 240, 210)
        End If
    End Sub

    ' ================================================================
    '  BLOCK/UNBLOCK INTERNET
    ' ================================================================
    Private Sub InternetFirewallToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles InternetFirewallToolStripMenuItem.Click
        Me.ActiveControl = Nothing
        If dgvBlockList.SelectedRows.Count = 0 Then
            MsgBox("Select a program from the list first.", MsgBoxStyle.Exclamation, "Warning") : Exit Sub
        End If
        Dim row As DataGridViewRow = dgvBlockList.SelectedRows(0)
        Dim filePath As String = row.Cells(COL_PATH).Value.ToString()
        Dim isBlocked As Boolean = (row.Cells(COL_INTERNET).Value.ToString() = "BLOCKED")
        Try
            If isBlocked Then
                ToggleFirewallRule(filePath, False)
                MsgBox("Internet blocking DISABLED for: " & vbCrLf & Path.GetFileName(filePath), MsgBoxStyle.Information, "Success")
            Else
                AddOrEnableFirewallRule(filePath)
                MsgBox("Internet blocking ENABLED for: " & vbCrLf & Path.GetFileName(filePath), MsgBoxStyle.Information, "Success")
            End If
            RefreshRowStatus(row, filePath)
        Catch ex As Exception
            MsgBox("Failed: " & ex.Message & vbCrLf & "Please run as administrator.", MsgBoxStyle.Critical, "Error")
        End Try
    End Sub

    ' ================================================================
    '  BLOCK/UNBLOCK EXECUTION  <-- DILINDUNGI TRIAL/LISENSI
    ' ================================================================
    Private Sub RunningToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RunningToolStripMenuItem.Click
        Me.ActiveControl = Nothing

        ' === CEK TRIAL / LISENSI ===
        If Not CanUseExecutionBlock() Then Exit Sub

        If dgvBlockList.SelectedRows.Count = 0 Then
            MsgBox("Please select a program from the list first!", MsgBoxStyle.Exclamation, "Warning") : Exit Sub
        End If

        Dim row As DataGridViewRow = dgvBlockList.SelectedRows(0)
        Dim filePath As String = row.Cells(COL_PATH).Value.ToString()
        Dim isBlocked As Boolean = (row.Cells(COL_RUN).Value.ToString() = "BLOCKED")

        Try
            If isBlocked Then
                RemoveRunBlock(filePath)
                MsgBox("Execution blocking DISABLED for:" & vbCrLf & Path.GetFileName(filePath), MsgBoxStyle.Information, "Success")
            Else
                AddRunBlock(filePath)
                MsgBox("Execution blocking ENABLED for:" & vbCrLf & Path.GetFileName(filePath) & _
                       vbCrLf & "The program cannot be opened until the block is removed.", MsgBoxStyle.Information, "Success")
            End If
            RefreshRowStatus(row, filePath)
        Catch ex As Exception
            MsgBox("Failed: " & ex.Message & vbCrLf & "Run as administrator.", MsgBoxStyle.Critical, "Error")
        End Try
    End Sub

    ' ================================================================
    '  UNBLOCK ALL
    ' ================================================================
    Private Sub ToolStripButton2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton2.Click
        Me.ActiveControl = Nothing
        If dgvBlockList.SelectedRows.Count = 0 Then
            MsgBox("Please select a program from the list first!", MsgBoxStyle.Exclamation, "Warning") : Exit Sub
        End If
        Dim row As DataGridViewRow = dgvBlockList.SelectedRows(0)
        Dim filePath As String = row.Cells(COL_PATH).Value.ToString()
        Dim confirm As MsgBoxResult = MsgBox("Remove ALL blocks for:" & vbCrLf & Path.GetFileName(filePath) & "?", _
                                             MsgBoxStyle.Question Or MsgBoxStyle.YesNo, "Confirmation")
        If confirm <> MsgBoxResult.Yes Then Exit Sub
        Try
            RemoveFirewallRule(filePath)
            RemoveRunBlock(filePath)
            RefreshRowStatus(row, filePath)
            MsgBox("All blocks have been successfully removed!", MsgBoxStyle.Information, "Success")
        Catch ex As Exception
            MsgBox("Error: " & ex.Message, MsgBoxStyle.Critical, "Error")
        End Try
    End Sub

    ' ================================================================
    '  REFRESH
    ' ================================================================
    Private Sub ToolStripButton3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton3.Click
        Me.ActiveControl = Nothing
        RefreshAllStatus()
        lblInfo.Text = "Status updated: " & Now.ToString("HH:mm:ss")
    End Sub

    ' ================================================================
    '  HAPUS DARI LIST
    ' ================================================================
    Private Sub ToolStripButton4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton4.Click
        Me.ActiveControl = Nothing
        If dgvBlockList.SelectedRows.Count = 0 Then
            MsgBox("Please select a program from the list first!", MsgBoxStyle.Exclamation, "Warning") : Exit Sub
        End If
        Dim row As DataGridViewRow = dgvBlockList.SelectedRows(0)
        Dim filePath As String = row.Cells(COL_PATH).Value.ToString()
        Dim fileName As String = Path.GetFileName(filePath)
        Dim isAnyBlocked As Boolean = (row.Cells(COL_INTERNET).Value.ToString() = "BLOCKED" OrElse _
                                       row.Cells(COL_RUN).Value.ToString() = "BLOCKED")
        Dim msg As String = "Remove '" & fileName & "' from the list?"
        If isAnyBlocked Then
            msg &= vbCrLf & vbCrLf & "WARNING: This program is still blocked!" & _
                   vbCrLf & "Also remove the block? (Yes = remove block, No = only remove from list)"
            Dim res As MsgBoxResult = MsgBox(msg, MsgBoxStyle.Question Or MsgBoxStyle.YesNoCancel, "Confirmation")
            If res = MsgBoxResult.Cancel Then Exit Sub
            If res = MsgBoxResult.Yes Then
                On Error Resume Next
                RemoveFirewallRule(filePath)
                RemoveRunBlock(filePath)
                On Error GoTo 0
            End If
        Else
            If MsgBox(msg, MsgBoxStyle.Question Or MsgBoxStyle.YesNo, "Confirmation") <> MsgBoxResult.Yes Then Exit Sub
        End If
        dgvBlockList.Rows.Remove(row)
        SaveList()
    End Sub

    ' ================================================================
    '  REFRESH STATUS
    ' ================================================================
    Private Sub RefreshRowStatus(ByVal row As DataGridViewRow, ByVal filePath As String)
        UpdateRowCells(row, CheckFirewallRuleExists(filePath), CheckRunBlockExists(filePath))
        UpdateActionButtons(row)
    End Sub

    Private Sub RefreshAllStatus()
        For Each row As DataGridViewRow In dgvBlockList.Rows
            If row.Cells(COL_PATH).Value IsNot Nothing Then
                Dim fp As String = row.Cells(COL_PATH).Value.ToString()
                UpdateRowCells(row, CheckFirewallRuleExists(fp), CheckRunBlockExists(fp))
            End If
        Next
        If dgvBlockList.SelectedRows.Count > 0 Then UpdateActionButtons(dgvBlockList.SelectedRows(0))
    End Sub

    ' ================================================================
    '  UPDATE TEKS TOMBOL
    ' ================================================================
    Private Sub UpdateActionButtons(ByVal row As DataGridViewRow)
        If row Is Nothing Then Exit Sub
        Dim internetBlocked As Boolean = (row.Cells(COL_INTERNET).Value IsNot Nothing AndAlso _
                                          row.Cells(COL_INTERNET).Value.ToString() = "BLOCKED")
        Dim runBlocked As Boolean = (row.Cells(COL_RUN).Value IsNot Nothing AndAlso _
                                     row.Cells(COL_RUN).Value.ToString() = "BLOCKED")

        ' Internet
        If internetBlocked Then
            InternetFirewallToolStripMenuItem.Text = "Allow Internet"
            InternetFirewallToolStripMenuItem.Image = My.Resources.icons8_protect_16
            BlockInternetToolStripMenuItem.Text = "Allow Internet"
            BlockInternetToolStripMenuItem.Image = My.Resources.icons8_protect_16
            InternetFirewallToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(34, 120, 34)
        Else
            InternetFirewallToolStripMenuItem.Text = "Block Internet"
            InternetFirewallToolStripMenuItem.Image = My.Resources.icons8_delete_shield_16
            BlockInternetToolStripMenuItem.Text = "Block Internet"
            BlockInternetToolStripMenuItem.Image = My.Resources.icons8_delete_shield_16
            InternetFirewallToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(180, 40, 40)
        End If

        ' Execution
        If _isLicensed Then
            ' Licensed: tampilan normal
            If runBlocked Then
                RunningToolStripMenuItem.Text = "Allow Execution"
                RunningToolStripMenuItem.Image = My.Resources.icons8_protect_16
                BlockExecutionsToolStripMenuItem.Text = "Allow Execution"
                BlockExecutionsToolStripMenuItem.Image = My.Resources.icons8_protect_16
                RunningToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(34, 120, 34)
            Else
                RunningToolStripMenuItem.Text = "Block Execution"
                RunningToolStripMenuItem.Image = My.Resources.icons8_delete_shield_16
                BlockExecutionsToolStripMenuItem.Text = "Block Execution"
                BlockExecutionsToolStripMenuItem.Image = My.Resources.icons8_delete_shield_16
                RunningToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(180, 40, 40)
            End If
        Else
            ' Trial: tampilkan sisa pemakaian
            Dim remaining As Integer = LicenseManager.GetTrialRemaining()
            Dim suffix As String
            If remaining > 0 Then
                suffix = "  [Trial: " & remaining & " left]"
                RunningToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(180, 40, 40)
            Else
                suffix = "  [Activate Required]"
                RunningToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(140, 130, 120)
            End If
            If runBlocked Then
                RunningToolStripMenuItem.Text = "Allow Execution" & suffix
                RunningToolStripMenuItem.Image = My.Resources.icons8_protect_16
                BlockExecutionsToolStripMenuItem.Text = "Allow Execution" & suffix
                BlockExecutionsToolStripMenuItem.Image = My.Resources.icons8_protect_16
            Else
                RunningToolStripMenuItem.Text = "Block Execution" & suffix
                RunningToolStripMenuItem.Image = My.Resources.icons8_delete_shield_16
                BlockExecutionsToolStripMenuItem.Text = "Block Execution" & suffix
                BlockExecutionsToolStripMenuItem.Image = My.Resources.icons8_delete_shield_16
            End If
        End If
    End Sub

    ' ================================================================
    '  SELECTION CHANGED
    ' ================================================================
    Private Sub dgvBlockList_SelectionChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dgvBlockList.SelectionChanged
        Dim hasSelection As Boolean = (dgvBlockList.SelectedRows.Count > 0)
        InternetFirewallToolStripMenuItem.Enabled = hasSelection
        RunningToolStripMenuItem.Enabled = hasSelection
        BlockInternetToolStripMenuItem.Enabled = hasSelection
        BlockExecutionsToolStripMenuItem.Enabled = hasSelection
        UnblockAllToolStripMenuItem.Enabled = hasSelection
        ToolStripButton2.Enabled = hasSelection
        ToolStripButton4.Enabled = hasSelection

        If hasSelection Then
            UpdateActionButtons(dgvBlockList.SelectedRows(0))
            Dim row As DataGridViewRow = dgvBlockList.SelectedRows(0)
            If row.Cells(COL_PATH).Value IsNot Nothing Then
                lblSelected.Text = "Selected: " & row.Cells(COL_PATH).Value.ToString()
            End If
            Panel1.Visible = False
        Else
            lblSelected.Text = "Select a program from the list to manage blocking"
            ResetActionButtons()
            Panel1.Visible = True
        End If
    End Sub

    Private Sub ResetActionButtons()
        InternetFirewallToolStripMenuItem.Text = "Block Internet"
        BlockInternetToolStripMenuItem.Text = "Block Internet"
        InternetFirewallToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(180, 40, 40)

        If _isLicensed Then
            RunningToolStripMenuItem.Text = "Block Execution"
            BlockExecutionsToolStripMenuItem.Text = "Block Execution"
            RunningToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(180, 40, 40)
        Else
            Dim remaining As Integer = LicenseManager.GetTrialRemaining()
            Dim suffix As String = If(remaining > 0, "  [Trial: " & remaining & " left]", "  [Activate Required]")
            RunningToolStripMenuItem.Text = "Block Execution" & suffix
            BlockExecutionsToolStripMenuItem.Text = "Block Execution" & suffix
            RunningToolStripMenuItem.BackColor = If(remaining > 0, _
                System.Drawing.Color.FromArgb(180, 40, 40), _
                System.Drawing.Color.FromArgb(140, 130, 120))
        End If
    End Sub

    ' ================================================================
    '  SIMPAN / LOAD LIST
    ' ================================================================
    Private Sub SaveList()
        Try
            Dim lines As New System.Collections.ArrayList()
            For Each row As DataGridViewRow In dgvBlockList.Rows
                If row.Cells(COL_PATH).Value IsNot Nothing Then
                    lines.Add(row.Cells(COL_PATH).Value.ToString())
                End If
            Next
            File.WriteAllText(SaveFile, String.Join(vbCrLf, CType(lines.ToArray(GetType(String)), String())))
        Catch
        End Try
    End Sub

    Private Sub LoadSavedList()
        If Not File.Exists(SaveFile) Then Exit Sub
        Try
            Dim lines As String() = File.ReadAllLines(SaveFile)
            For Each line As String In lines
                Dim trimmed As String = line.Trim()
                If trimmed.Length > 0 Then
                    Dim alreadyExist As Boolean = False
                    For Each row As DataGridViewRow In dgvBlockList.Rows
                        If row.Cells(COL_PATH).Value IsNot Nothing Then
                            If row.Cells(COL_PATH).Value.ToString().ToLower() = trimmed.ToLower() Then
                                alreadyExist = True : Exit For
                            End If
                        End If
                    Next
                    If Not alreadyExist Then AddRowToGrid(trimmed)
                End If
            Next
        Catch
        End Try
    End Sub

    ' ================================================================
    '  FIREWALL
    ' ================================================================
    Private Function CheckFirewallRuleExists(ByVal programPath As String) As Boolean
        Try
            Dim fwPolicy2 As Object = CreateObject("HNetCfg.FwPolicy2")
            Dim ruleName As String = "AppBlock_" & Path.GetFileName(programPath)
            For Each r As Object In fwPolicy2.Rules
                If r.Name = ruleName OrElse r.Name = ruleName & "_IN" Then
                    If CBool(r.Enabled) = True Then Return True
                End If
            Next
        Catch
        End Try
        Return False
    End Function

    Private Sub AddOrEnableFirewallRule(ByVal programPath As String)
        Dim fwPolicy2 As Object = CreateObject("HNetCfg.FwPolicy2")
        Dim ruleName As String = "AppBlock_" & Path.GetFileName(programPath)
        Dim foundOut As Boolean = False, foundIn As Boolean = False
        For Each r As Object In fwPolicy2.Rules
            If r.Name = ruleName Then : r.Enabled = True : foundOut = True : End If
            If r.Name = ruleName & "_IN" Then : r.Enabled = True : foundIn = True : End If
        Next
        If Not foundOut Then
            Dim n As Object = CreateObject("HNetCfg.FWRule")
            n.Name = ruleName : n.Description = "AppBlocker: block outgoing - " & Path.GetFileName(programPath)
            n.ApplicationName = programPath : n.Action = ACTION_BLOCK
            n.Direction = DIRECTION_OUTBOUND : n.Enabled = True : n.InterfaceTypes = "All" : n.Profiles = 7
            fwPolicy2.Rules.Add(n)
        End If
        If Not foundIn Then
            Dim ni As Object = CreateObject("HNetCfg.FWRule")
            ni.Name = ruleName & "_IN" : ni.Description = "AppBlocker: block incoming - " & Path.GetFileName(programPath)
            ni.ApplicationName = programPath : ni.Action = ACTION_BLOCK
            ni.Direction = DIRECTION_INBOUND : ni.Enabled = True : ni.InterfaceTypes = "All" : ni.Profiles = 7
            fwPolicy2.Rules.Add(ni)
        End If
    End Sub

    Private Sub ToggleFirewallRule(ByVal programPath As String, ByVal enableState As Boolean)
        Dim fwPolicy2 As Object = CreateObject("HNetCfg.FwPolicy2")
        Dim ruleName As String = "AppBlock_" & Path.GetFileName(programPath)
        For Each r As Object In fwPolicy2.Rules
            If r.Name = ruleName OrElse r.Name = ruleName & "_IN" Then r.Enabled = enableState
        Next
    End Sub

    Private Sub RemoveFirewallRule(ByVal programPath As String)
        Dim fwPolicy2 As Object = CreateObject("HNetCfg.FwPolicy2")
        Dim ruleName As String = "AppBlock_" & Path.GetFileName(programPath)
        On Error Resume Next
        fwPolicy2.Rules.Remove(ruleName) : fwPolicy2.Rules.Remove(ruleName & "_IN")
        On Error GoTo 0
    End Sub

    ' ================================================================
    '  IFEO (RUN BLOCK)
    ' ================================================================
    Private Function CheckRunBlockExists(ByVal programPath As String) As Boolean
        Try
            Dim key As RegistryKey = Registry.LocalMachine.OpenSubKey(IFEO_KEY & "\" & Path.GetFileName(programPath), False)
            If key IsNot Nothing Then
                Dim val As Object = key.GetValue("Debugger")
                key.Close()
                If val IsNot Nothing Then Return True
            End If
        Catch
        End Try
        Return False
    End Function

    Private Sub AddRunBlock(ByVal programPath As String)
        Dim key As RegistryKey = Registry.LocalMachine.CreateSubKey(IFEO_KEY & "\" & Path.GetFileName(programPath))
        If key IsNot Nothing Then
            key.SetValue("_OriginalPath", programPath, RegistryValueKind.String)
            key.SetValue("Debugger", """" & DEBUGGER_BLOCK & """", RegistryValueKind.String)
            key.Close()
        Else
            Throw New Exception("Unable to create registry key. Run as administrator.")
        End If
    End Sub

    Private Sub RemoveRunBlock(ByVal programPath As String)
        Try
            Dim keyPath As String = IFEO_KEY & "\" & Path.GetFileName(programPath)
            Dim key As RegistryKey = Registry.LocalMachine.OpenSubKey(keyPath, True)
            If key IsNot Nothing Then
                key.DeleteValue("Debugger", False)
                key.DeleteValue("_OriginalPath", False)
                If key.ValueCount = 0 AndAlso key.SubKeyCount = 0 Then
                    key.Close() : Registry.LocalMachine.DeleteSubKey(keyPath, False)
                Else
                    key.Close()
                End If
            End If
        Catch ex As Exception
            Throw New Exception("Failed to remove run block: " & ex.Message)
        End Try
    End Sub

    ' ================================================================
    '  DELEGASI
    ' ================================================================
    Private Sub ToolStripSplitButton1_ButtonClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripSplitButton1.ButtonClick
        ToolStripSplitButton1.ShowDropDown()
    End Sub
    Private Sub BlockInternetToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BlockInternetToolStripMenuItem.Click
        InternetFirewallToolStripMenuItem.PerformClick()
    End Sub
    Private Sub BlockExecutionsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BlockExecutionsToolStripMenuItem.Click
        RunningToolStripMenuItem.PerformClick()
    End Sub
    Private Sub UnblockAllToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UnblockAllToolStripMenuItem.Click
        ToolStripButton2.PerformClick()
    End Sub
    Private Sub RefreshToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RefreshToolStripMenuItem.Click
        ToolStripButton3.PerformClick()
    End Sub
    Private Sub SelectEXEProgramToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SelectEXEProgramToolStripMenuItem.Click
        ToolStripButton1.PerformClick()
    End Sub
    Private Sub MenuStrip1_ItemClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles MenuStrip1.ItemClicked
    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.ActiveControl = Nothing : ToolStripButton1.PerformClick()
    End Sub
    Private Sub Panel1_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles Panel1.Paint
    End Sub
    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem.Click
        Application.Exit()
    End Sub
    Private Sub AboutToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AboutToolStripMenuItem.Click
        frmAbout.ShowDialog()
    End Sub
    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Process.Start("mailto:programblocker@gmail.com")
    End Sub
    Private Sub SendFeedbackToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SendFeedbackToolStripMenuItem.Click
        Process.Start("mailto:programblocker@gmail.com")
    End Sub

    Private Sub ToolStrip1_ItemClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles ToolStrip1.ItemClicked

    End Sub
End Class