﻿Imports Microsoft.Win32
Imports System.Security.Cryptography
Imports System.Text

Public Module LicenseManager

    ' ============================================================
    '  KONFIGURASI
    ' ============================================================
    Private Const SECRET_SALT As String = "ProgramBlocker@2024#Secret!XYZ"
    Private Const KEY_PREFIX As String = "ABK"
    Private Const REG_KEY_PATH As String = "SOFTWARE\ProgramBlocker"
    Private Const REG_VALUE_LICENSE As String = "LicenseKey"
    Private Const REG_VALUE_TRIAL As String = "TrialUsage"
    Private Const MAX_TRIAL As Integer = 10

    ' ============================================================
    '  VALIDASI SERIAL KEY
    ' ============================================================
    Public Function IsValidKey(ByVal rawKey As String) As Boolean
        If rawKey Is Nothing OrElse rawKey.Trim().Length = 0 Then Return False
        Dim key As String = rawKey.Trim().ToUpper()
        If Not key.StartsWith(KEY_PREFIX & "-") Then Return False
        Dim parts() As String = key.Split("-"c)
        If parts.Length <> 5 Then Return False
        For i As Integer = 1 To 4
            If parts(i).Length <> 5 Then Return False
            For Each c As Char In parts(i)
                If "0123456789ABCDEF".IndexOf(c) < 0 Then Return False
            Next
        Next
        Dim body As String = parts(1) & parts(2) & parts(3) & parts(4)
        Return (body.Substring(16, 4) = ComputeChecksum(body.Substring(0, 16)))
    End Function

    Private Function ComputeChecksum(ByVal dataBlock As String) As String
        Dim hashBytes() As Byte
        Using sha As New SHA256Managed()
            hashBytes = sha.ComputeHash(Encoding.UTF8.GetBytes(SECRET_SALT & dataBlock))
        End Using
        Return BitConverter.ToString(hashBytes, 0, 2).Replace("-", "").ToUpper()
    End Function

    ' ============================================================
    '  SIMPAN / BACA LISENSI (HKCU)
    ' ============================================================
    Public Sub SaveLicense(ByVal key As String)
        Try
            Dim regKey As RegistryKey = Registry.CurrentUser.CreateSubKey(REG_KEY_PATH)
            If regKey IsNot Nothing Then
                regKey.SetValue(REG_VALUE_LICENSE, ObfuscateString(key.Trim().ToUpper()), RegistryValueKind.String)
                regKey.Close()
            End If
        Catch
        End Try
    End Sub

    Public Function LoadAndValidateLicense() As Boolean
        Try
            Dim regKey As RegistryKey = Registry.CurrentUser.OpenSubKey(REG_KEY_PATH, False)
            If regKey Is Nothing Then Return False
            Dim raw As Object = regKey.GetValue(REG_VALUE_LICENSE)
            regKey.Close()
            If raw Is Nothing Then Return False
            Return IsValidKey(DeobfuscateString(raw.ToString()))
        Catch
            Return False
        End Try
    End Function

    ' ============================================================
    '  TRIAL USAGE - SIMPAN / BACA JUMLAH PEMAKAIAN
    ' ============================================================

    ''' <summary>Ambil jumlah pemakaian trial saat ini.</summary>
    Public Function GetTrialUsageCount() As Integer
        Try
            Dim regKey As RegistryKey = Registry.CurrentUser.OpenSubKey(REG_KEY_PATH, False)
            If regKey Is Nothing Then Return 0
            Dim val As Object = regKey.GetValue(REG_VALUE_TRIAL)
            regKey.Close()
            If val Is Nothing Then Return 0
            ' Nilai disimpan ter-obfuscate juga
            Dim decoded As String = DeobfuscateString(val.ToString())
            Dim count As Integer = 0
            If Integer.TryParse(decoded, count) Then Return count
        Catch
        End Try
        Return 0
    End Function

    ''' <summary>Simpan jumlah pemakaian trial (increment 1).</summary>
    Public Sub IncrementTrialUsage()
        Try
            Dim current As Integer = GetTrialUsageCount()
            Dim newVal As Integer = current + 1
            Dim regKey As RegistryKey = Registry.CurrentUser.CreateSubKey(REG_KEY_PATH)
            If regKey IsNot Nothing Then
                regKey.SetValue(REG_VALUE_TRIAL, ObfuscateString(newVal.ToString()), RegistryValueKind.String)
                regKey.Close()
            End If
        Catch
        End Try
    End Sub

    ''' <summary>Sisa pemakaian trial (0 jika sudah habis).</summary>
    Public Function GetTrialRemaining() As Integer
        Dim used As Integer = GetTrialUsageCount()
        Dim remaining As Integer = MAX_TRIAL - used
        If remaining < 0 Then Return 0
        Return remaining
    End Function

    ''' <summary>True jika masih ada sisa trial.</summary>
    Public Function HasTrialRemaining() As Boolean
        Return GetTrialRemaining() > 0
    End Function

    ''' <summary>Jumlah maksimal trial.</summary>
    Public Function GetMaxTrial() As Integer
        Return MAX_TRIAL
    End Function

    ' ============================================================
    '  OBFUSCATION XOR
    ' ============================================================
    Private Function ObfuscateString(ByVal input As String) As String
        Dim saltBytes() As Byte = Encoding.UTF8.GetBytes(SECRET_SALT)
        Dim inputBytes() As Byte = Encoding.UTF8.GetBytes(input)
        Dim result(inputBytes.Length - 1) As Byte
        For i As Integer = 0 To inputBytes.Length - 1
            result(i) = CByte(inputBytes(i) Xor saltBytes(i Mod saltBytes.Length))
        Next
        Return Convert.ToBase64String(result)
    End Function

    Private Function DeobfuscateString(ByVal input As String) As String
        Try
            Dim saltBytes() As Byte = Encoding.UTF8.GetBytes(SECRET_SALT)
            Dim inputBytes() As Byte = Convert.FromBase64String(input)
            Dim result(inputBytes.Length - 1) As Byte
            For i As Integer = 0 To inputBytes.Length - 1
                result(i) = CByte(inputBytes(i) Xor saltBytes(i Mod saltBytes.Length))
            Next
            Return Encoding.UTF8.GetString(result)
        Catch
            Return ""
        End Try
    End Function

    ' ============================================================
    '  GENERATOR KEY (tool admin terpisah)
    ' ============================================================
    Public Function GenerateKey() As String
        Dim rng As New Random(Environment.TickCount)
        Dim hexChars As String = "0123456789ABCDEF"
        Dim dataBlock As New StringBuilder()
        For i As Integer = 1 To 16
            dataBlock.Append(hexChars(rng.Next(16)))
        Next
        Dim checksum As String = ComputeChecksum(dataBlock.ToString())
        Dim body As String = dataBlock.ToString() & checksum
        Return KEY_PREFIX & "-" & body.Substring(0, 5) & "-" & body.Substring(5, 5) & _
               "-" & body.Substring(10, 5) & "-" & body.Substring(15, 5)
    End Function

End Module