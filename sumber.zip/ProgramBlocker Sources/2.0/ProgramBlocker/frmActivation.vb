﻿Public Class frmActivation
    Public Property ActivationSuccess As Boolean = False
    Private Sub frmActivation_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
       
    End Sub

    Private Sub btnActivate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnActivate.Click
        Dim key As String = txtSerialKey.Text.Trim()

        If key.Length = 0 OrElse key = "ABK-" Then
            ShowStatus("Please enter a serial key.", False)
            Exit Sub
        End If

        If LicenseManager.IsValidKey(key) Then
            LicenseManager.SaveLicense(key)
            ShowStatus("Activation successful! Block Execution is now unlocked.", True)
            btnActivate.Enabled = False
            Me.ActivationSuccess = True

            ' Tutup form otomatis setelah 1.5 detik
            Dim t As New System.Windows.Forms.Timer()
            t.Interval = 1500
            AddHandler t.Tick, Sub(s, ea)
                                   t.Stop()
                                   Me.DialogResult = DialogResult.OK
                                   Me.Close()
                               End Sub
            t.Start()
        Else
            ShowStatus("Invalid serial key. Please check and try again.", False)
            txtSerialKey.Focus()
            txtSerialKey.SelectAll()
        End If

    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Me.ActivationSuccess = False
        Me.DialogResult = DialogResult.Cancel
        Me.Close()
    End Sub

    Private Sub txtSerialKey_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtSerialKey.KeyDown
        If e.KeyCode = Keys.Enter Then
            btnActivate.PerformClick()
        End If

    End Sub
    Private Sub ShowStatus(ByVal msg As String, ByVal success As Boolean)
        lblStatus.Text = msg
        lblStatus.ForeColor = If(success, System.Drawing.Color.FromArgb(0, 140, 60), System.Drawing.Color.FromArgb(180, 30, 30))
    End Sub

    Private Sub txtSerialKey_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtSerialKey.TextChanged
        ' Pastikan selalu diawali dengan "ABK-"
       

    End Sub

    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Process.Start("https://programblocker.github.io/buy.html")
        Me.Close()
    End Sub
End Class